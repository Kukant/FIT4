// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: calculatingblock.h

#ifndef CALCULATIONBLOCK_H
#define CALCULATIONBLOCK_H

#include "includes.h"
#include "block.h"
#include "port.h"

/**
 * @class CalculatingBlock
 * @ingroup Frontend block
 *
 * This class represents block for calculating.
 */
class CalculatingBlock : public Block
{
public:
    /**
     * Create an CalculatingBlock.
     * @param blockType For set icon of a block.
     * @param mainScene Parameter for block (parent) constructor.
     */
    CalculatingBlock(BlockType blockType, DiagramScene *mainScene);

private:
    /**
     * Input port 1.
     */
    Port inPort1;

    /**
     * Input port 2.
     */
    Port inPort2;

    /**
     * Output port.
     */
    Port outPort;

    /**
     * ToDo.
     */
    virtual void deleteThis() Q_DECL_OVERRIDE;

    /**
     * ToDo.
     */
    virtual Port *getPortPointer(PortType portType) Q_DECL_OVERRIDE;
};

#endif // CALCULATINGBLOCK_H
