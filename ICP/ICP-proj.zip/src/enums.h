// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: enums.h

#ifndef ENUMS_H
#define ENUMS_H

const int BLOCK_Z_VALUE = 100;

/**
 * Type of blocks.
 */
enum BlockType {
    BLOCK_ADD,
    BLOCK_SUB,
    BLOCK_MUL,
    BLOCK_DIV,
    BLOCK_RESULT,
    BLOCK_INPUT
};

/**
 * Type of objects.
 */
enum ObjectType {
    OBJ_BLOCK,
    OBJ_PORT,
    OBJ_NONE
};

/**
 * Type of ports.
 */
enum PortType {
    PORT_IN_0,
    PORT_IN_1,
    PORT_OUT
};

/**
 * ToDo.
 */
enum SceneObjectType {
    BLOCKT,
    WIRET
};

#endif // ENUMS_H
