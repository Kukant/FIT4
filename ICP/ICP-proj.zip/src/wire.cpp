// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: wire.cpp

#include "wire.h"
#include "port.h"
#include "enums.h"
#include "block.h"
#include "b_block.h"

Wire::Wire(Port *origin, Port *end, DiagramScene *mainScene)
{
    setFlag(QGraphicsItem::ItemIsSelectable,false);
    if (origin->portType == PORT_IN_0 || origin->portType == PORT_IN_1) {
        originPort = end;
        endingPort = origin;
    } else {
        originPort = origin;
        endingPort = end;
    }

    startingPoint = originPort->centerPoint();
    endingPoint = endingPort->centerPoint();
    // connect blocks in the backend
    B_Block *orig = originPort->parentBlock->bblock;
    B_Block *dest = endingPort->parentBlock->bblock;
    int index = endingPort->portType == PORT_IN_0 ? 0 : 1;

    orig->bindOutput(dest, index);
    dest->bindInput(orig, index);

    this->mainScene = mainScene;
    this->mainScene->allWires.append(this);
}

Wire::Wire(DiagramScene *mainScene)
{
    this->mainScene = mainScene;
    this->mainScene->allWires.append(this);
}

/// This will call disconnectWire(self) on all connected ports
/// \brief Wire::remove
///
void Wire::removeWire() {
    B_Block *orig = originPort->parentBlock->bblock; // TADY SEG FAULT
    B_Block *dest = endingPort->parentBlock->bblock;
    int index = endingPort->portType == PORT_IN_0 ? 0 : 1;
    orig->unbindOutput(dest, index);

    originPort->disconnectWire(this);
    endingPort->disconnectWire(this);

    mainScene->allWires.removeOne(this);
    delete this;
}

void Wire::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->setPen(QPen(Qt::black,2));
    painter->drawLine(originPort->centerPoint(),endingPort->centerPoint());
    setZValue(10);
    (void) option; // only for dissapear of warning
    (void) widget; // only for dissapear of warning
}


QRectF Wire::boundingRect() const
{
    return QRectF(startingPoint,endingPoint);
}

void Wire::save(QDataStream &stream) {
    Block *orig = originPort->parentBlock;
    Block *dest = endingPort->parentBlock;
    int index = endingPort->portType;

    stream << (quint64) orig;
    stream << (quint64) dest;
    stream << index;
}

void Wire::load(QDataStream &stream, QMap<Block *, Block *> &oldNewPointerMap) {
    quint64 orig_int;
    quint64 dest_int;
    int index;

    stream >> orig_int;
    stream >> dest_int;
    stream >> index;

    Block *origB = (Block *) orig_int;
    Block *destB = (Block *) dest_int;

    originPort = oldNewPointerMap[origB]->getPortPointer(PORT_OUT);
    endingPort = oldNewPointerMap[destB]->getPortPointer((PortType)index);

    originPort->connectWire(this);
    endingPort->connectWire(this);

    startingPoint = originPort->centerPoint();
    endingPoint = endingPort->centerPoint();
    // connect blocks in the backend
    B_Block *orig = originPort->parentBlock->bblock;
    B_Block *dest = endingPort->parentBlock->bblock;
    index = endingPort->portType == PORT_IN_0 ? 0 : 1;

    orig->bindOutput(dest, index);
    dest->bindInput(orig, index);
}
