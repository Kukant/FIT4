// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: b_block.cpp

#include "b_block.h"

B_Block::B_Block(int inputsNum):
    inputValues(inputsNum),
    inputs(inputsNum),
    outputs()
{
    myVal.defined = false;
}

void B_Block::bindInput(B_Block *b, int index)
{
    inputs.at(index) = b;
}

/// This will be called when block is being destroyed
/// so the value is not sent to undefined location.
/// \brief B_Block::unbindInputs
///
void B_Block::unbindInputs()
{
    for (unsigned i = 0; i < inputs.size(); i++)
        if (inputs.at(i))
            inputs.at(i)->unbindOutput(this, i);
}


void B_Block::unbindInput(int index)
{
    inputs.at(index) = NULL;
}

void B_Block::bindOutput(B_Block *b, int index)
{
    Block_IndexT *o = new Block_IndexT();
    o->block = b;
    o->index = index;
    outputs.append(o);
}

void B_Block::unbindOutput(B_Block *b, int index)
{
    for (int i = 0; i < outputs.length(); i++) {
        Block_IndexT *o = outputs.at(i);
        if (o->block == b && o->index == index) {
            outputs.removeAt(i);
            break;
        }
    }

    b->unbindInput(index);
}

int B_Block::sendVal() {
    if (myVal.defined) {
        return 1;
    }

    for (unsigned i = 0; i < inputValues.size(); i++) {
        if (!inputValues.at(i).defined) {
            // if at least one input value is undefined
            return 1;
        }
    }

    // all input values are defined
    myVal.defined = true;
    myVal.value = calculate();
    for (int i = 0; i < outputs.length(); i++) {
        Block_IndexT *o = outputs.at(i);
        o->block->inputValues.at(o->index).value = myVal.value;
        o->block->inputValues.at(o->index).defined = true;
    }

    return 0;
}
