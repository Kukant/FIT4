// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: inputblock.h

#ifndef INPUTBLOCK_H
#define INPUTBLOCK_H

#include "includes.h"
#include "block.h"
#include "port.h"

class DecimalData;

/**
 * @class InputBlock
 * @ingroup Frontend block
 *
 * This class represents block for reading input.
 */
class InputBlock : public Block
{
public:
    /**
     * Create an InputBlock.
     * @param value Input value.
     * @param mainScene Parameter for block (parent) constructor.
     */
    InputBlock(DiagramScene *mainScene, double value);

private:
    /**
     * Input value.
     */
    double value;

    /**
     * Output port.
     */
    Port outPort;

    /**
     * ToDo.
     */
    virtual void deleteThis() Q_DECL_OVERRIDE;

    /**
     * ToDo.
     */
    virtual Port *getPortPointer(PortType portType) Q_DECL_OVERRIDE;

    /**
     * ToDo.
     */
    virtual void save(QDataStream &stream) Q_DECL_OVERRIDE;

    /**
     * ToDo.
     */
    virtual void load(QDataStream &stream) Q_DECL_OVERRIDE;
};

#endif // INPUTBLOCK_H
