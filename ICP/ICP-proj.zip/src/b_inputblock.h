// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: b_inputblock.h

#ifndef B_INPUTBLOCK_H
#define B_INPUTBLOCK_H

#include "includes.h"
#include "b_block.h"

/**
 * @class B_InputBlock
 * @defgroup Input backend block
 * @ingroup Input backend block
 *
 * This represents Input Block in backend.
 */
class B_InputBlock :  public B_Block
{
public:
    B_InputBlock(double in);
    double calculate();
};

#endif // B_INPUTBLOCK_H
