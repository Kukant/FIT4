// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: b_resultblock.h

#ifndef B_RESULTBLOCK_H
#define B_RESULTBLOCK_H

#include "includes.h"
#include "b_block.h"

/**
 * @class B_ResultBlock
 * @defgroup Result backend block
 * @ingroup Result backend block
 *
 * This represents Result Block in backend.
 */
class B_ResultBlock : public B_Block
{
public:
    B_ResultBlock();
    double calculate();
};

#endif // B_RESULTBLOCK_H
