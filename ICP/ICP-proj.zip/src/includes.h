// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: includes.h

#ifndef INCLUDES_H
#define INCLUDES_H

#include <iostream>
#include <vector>
#include <string>
#include <typeinfo>
#include <algorithm>

#include <QMainWindow>
#include <QtWidgets>
#include <QGraphicsScene>
#include <QtCore>
#include <QtGui>
#include <QGraphicsSceneMouseEvent>
#include <QGraphicsSimpleTextItem>
#include <QFont>
#include <QPen>
#include <QColor>
#include <QGraphicsObject>
#include <QDataStream>
#include <QList>
#include <QObject>
#include <QWidget>
#include <QListWidget>
#include <QGraphicsLineItem>
#include <QGraphicsRectItem>
#include <QDialog>
#include <QPainter>
#include <QDoubleValidator>
#include <QRectF>
#include <QStyleOptionGraphicsItem>
#include <QLineEdit>
#include <QMessageBox>
#include <QInputDialog>

#endif // INCLUDES_H
