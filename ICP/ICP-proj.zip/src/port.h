// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: port.h

#ifndef PORT_H
#define PORT_H

#include "includes.h"
#include "diagramsceneobject.h"
#include "enums.h"

class Block;
class Wire;

/**
 * @class Port
 * @defgroup Frontend port
 * @ingroup Frontend port
 *
 * This class represents port of block.
 */
class Port : public DiagramSceneObject
{
public:
    /**
     * Create a Port.
     * @param x X coordinate.
     * @param y Y coordinate.
     * @param type Type of the port.
     * @param parentBlock Parent block.
     */
    Port(double x, double y, PortType type, Block *parentBlock);

    /**
     * If port is used.
     */
    bool used;

    /**
     * Get type of an object.
     * @return Type of object (port in this case).
     */
    ObjectType getObjType();

    /**
     * ToDo
     */
    QPointF centerPoint() Q_DECL_OVERRIDE;

    /**
     * Type of the port.
     */
    PortType portType;

    /**
     * ToDo.
     */
    void clearPort();

    /**
     * Will be called from DiagramScene
     *
     * @param toConnect
     * @return 0 if succes, 1 otherwise.
     */
    int connectWire(Wire *toConnect);

    /**
     * Will be called from wire.
     *
     * @param toDisconnect
     */
    void disconnectWire(Wire *toDisconnect);

    /**
     * Pointer to the parent block.
     */
    Block *parentBlock;

private:
    /**
     * ToDo
     */
    QList<Wire *> *connectedWires;

    /**
     * Form of the port (rectangle).
     */
    QRectF rectangle;

    /**
     * Only because of inheritance from DiagramSceneObject (virtual method).
     */
    QRectF boundingRect() const Q_DECL_OVERRIDE;

    /**
     * Only because of inheritance from DiagramSceneObject (virtual method).
     */
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) Q_DECL_OVERRIDE;
};

#endif // PORT_H
