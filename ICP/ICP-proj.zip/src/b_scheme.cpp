// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: b_scheme.cpp

#include "b_scheme.h"

B_Scheme::B_Scheme(): allBlocks()
{
}

void B_Scheme::addBlock(B_Block *b)
{
    allBlocks.push_back(b);
}

void B_Scheme::removeBlock(B_Block *b)
{
    allBlocks.erase(std::remove(allBlocks.begin(), allBlocks.end(), b), allBlocks.end());
}

void B_Scheme::nextStep()
{
    B_Block *b = nullptr;
    for (unsigned i = 0; i < allBlocks.size(); i++) {
        b = allBlocks.at(i);
        int ret = b->sendVal();
        if (ret == 0) // same value has been set
            return;
    }
}

bool B_Scheme::containNotBindedPort()
{
    for (auto const &block: allBlocks) {

        for (auto const &port: block->inputs) {
            if (port == nullptr) {
                return true;
            }
        }

        if (block->blockType != BLOCK_RESULT) {
            if (block->outputs.length() == 0) {
                return true;
            }
        }
    }
    return false;
}

bool B_Scheme::containCycleUtil(B_Block *block, std::vector<B_Block *> &inPath)
{
    foreach (Block_IndexT *block_out_struct, block->outputs) {

        if (std::find(inPath.begin(), inPath.end(), block_out_struct->block) != inPath.end()) {
            return true;
        }
        else {
            inPath.push_back(block_out_struct->block);
            bool retRec = this->containCycleUtil(block_out_struct->block, inPath);
            return retRec;
        }
    }
    return false;
}

bool B_Scheme::containCycle()
{
    for (auto const &block: allBlocks) {
        if (block->blockType == BLOCK_INPUT) {
            std::vector<B_Block *> inPath;
            inPath.push_back(block);

            if (containCycleUtil(block, inPath)) {
                return true;
            }
        }
    }
    return false;
}

