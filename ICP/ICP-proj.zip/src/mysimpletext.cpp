// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: mysipletext.cpp

#include "mysimpletext.h"

MySimpleText::MySimpleText(const QString &text, QGraphicsItem *parent): QGraphicsSimpleTextItem(text)
{
    setFlag(QGraphicsItem::ItemIsSelectable, false);
    (void) parent; // only for dissapear of warning
}

QRectF MySimpleText::boundingRect() const
{
    QRectF r = QGraphicsSimpleTextItem::boundingRect();
    r.adjust(40, 1, 1, 1);
    return r;
}

void MySimpleText::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    QStyleOptionGraphicsItem myOption(*option);
    myOption.state &= ~QStyle::State_Selected;
    QGraphicsSimpleTextItem::paint(painter, &myOption, widget);
    (void) option; // only for dissapear of warning
    (void) widget; // only for dissapear of warning
}
