// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: readinput.h

#ifndef READINPUT_H
#define READINPUT_H

#include "includes.h"
#include "ui_readinput.h"

/**
 * @class ReadInput
 * @defgroup Read input
 * @ingroup Read input
 *
 * Class for input processing.
 */
class ReadInput : public QDialog, public Ui::ReadInput
{
    Q_OBJECT

public:
    /**
     * Create a Port.
     * @param parent Parent.
     */
    explicit ReadInput(QWidget *parent = 0);

    /**
     * Destroy a Port.
     */
    ~ReadInput();

    /**
     * Get input value.
     */
    double getInputValue();

private:
    /**
     * ToDo.
     */
    Ui::ReadInput *ui;
};

#endif // READINPUT_H
