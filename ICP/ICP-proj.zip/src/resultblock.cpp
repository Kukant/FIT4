// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: resultblock.cpp

#include "resultblock.h"
#include "b_resultblock.h"
#include "diagramscene.h"

ResultBlock::ResultBlock(DiagramScene *mainScene):
    Block(mainScene),
    inPort(-45, -5, PORT_IN_0, this)
{
    inPort.setParentItem(this);
    icon.setText("=");

    bblock = new B_ResultBlock();
    this->mainScene = mainScene;
    mainScene->scheme.addBlock(bblock);

    thisType = BLOCK_RESULT;
}

void ResultBlock::deleteThis() {
    inPort.clearPort();
    this->scene()->update();
    delete this;
}

Port * ResultBlock::getPortPointer(PortType portType) {
    switch (portType) {
        case PORT_IN_0:
            return &inPort;
        case PORT_IN_1:
            return nullptr;
        case PORT_OUT:
            return nullptr;
    }

    return nullptr;
}
