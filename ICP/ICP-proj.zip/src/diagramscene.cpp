// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: diagramscene.cpp

#include "diagramscene.h"
#include "wire.h"
#include "port.h"
#include "calculationblock.h"
#include "inputblock.h"
#include "resultblock.h"
#include "block.h"
#include "readinput.h"

DiagramScene::DiagramScene(QObject *parent) :
    QGraphicsScene(parent),
    scheme(),
    allBlocks()
{
}

void DiagramScene::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsScene::mousePressEvent(event);

    if (listWidget->selectionModel()->hasSelection()) {

        BlockType blockType = static_cast<BlockType> (listWidget->currentRow());

        if (blockType == BLOCK_ADD || blockType == BLOCK_SUB || blockType == BLOCK_MUL || blockType == BLOCK_DIV) {
            CalculatingBlock *block = new CalculatingBlock(blockType, this);
            addBlockToList(block);
            addItem(block);
            block->setPos(event->scenePos());
        }
        else if (blockType == BLOCK_RESULT) {
            ResultBlock *block = new ResultBlock(this);
            addBlockToList(block);
            addItem(block);
            block->setPos(event->scenePos());
        }
        else if (blockType == BLOCK_INPUT) {

            ReadInput *input = new ReadInput();

            if (input->exec() != QDialog::Rejected) {
                double value = input->getInputValue();

                InputBlock *block = new InputBlock(this, value);
                addBlockToList(block);
                addItem(block);
                block->setPos(event->scenePos());
            }
            delete input;
        }

        listWidget->selectionModel()->clearSelection();
    }

    else if (items(event->scenePos()).count() > 0) { // click on some object
        DiagramSceneObject *itemUnderCursor = getObjectUnderCursor(event->scenePos());

        if (itemUnderCursor != nullptr) {
            if (itemUnderCursor->getObjType() == OBJ_PORT) { // ToDo: seg fault tady
                startingPort = dynamic_cast<Port *> (itemUnderCursor);
                newLine = new QGraphicsLineItem(QLineF(itemUnderCursor->centerPoint(), event->scenePos()));
                newLine->setPen(QPen(Qt::black, 3));
                newLine->setZValue(5000);
                addItem(newLine);
                currentMode = creatingLine;
            }
        }
    }
}

DiagramSceneObject *DiagramScene::getObjectUnderCursor(QPointF position)
{
    return qgraphicsitem_cast<DiagramSceneObject *> (items(position).first());
}

void DiagramScene::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsScene::mouseMoveEvent(event);

    if (currentMode == creatingLine) {
        QLineF moving(newLine->line().p1(), event->scenePos());
        newLine->setLine(moving);
    }

    update();
}

void DiagramScene::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    if (currentMode == creatingLine) {
        removeItem(newLine);
        delete newLine;
        newLine = nullptr;
        currentMode = movingObject;

        if (items(event->scenePos()).count() > 0) { // click on some object
            DiagramSceneObject *itemUnderCursor = getObjectUnderCursor(event->scenePos());
            if (itemUnderCursor != nullptr) {
                if (itemUnderCursor->getObjType() == OBJ_PORT) {
                    Port *endingPort = dynamic_cast<Port *> (itemUnderCursor);
                    bool isStartingInput = startingPort->portType == PORT_IN_0 || startingPort->portType == PORT_IN_1;
                    bool isEndingInput = endingPort->portType == PORT_IN_0 || endingPort->portType == PORT_IN_1;
                    bool haveSameParent = endingPort->parentBlock == startingPort->parentBlock;
                    if ( !haveSameParent && isStartingInput != isEndingInput) {
                        Wire *newWire = new Wire(startingPort, endingPort, this);
                        if (startingPort->connectWire(newWire) || endingPort->connectWire(newWire))
                            newWire->removeWire();
                        else {
                            addItem(newWire);
                            endingPort->used = true;
                            startingPort->used = true;
                        }
                    }
                }
            }
        }
    }
    update();
    QGraphicsScene::mouseReleaseEvent(event);
}

void DiagramScene::addBlockToList(Block *b)
{
    allBlocks.append(b);
}

void DiagramScene::removeBlockFromList(Block *b)
{
    allBlocks.removeOne(b);
}

void DiagramScene::calculateBtnClicked()
{
    if (scheme.containNotBindedPort()) {
        QMessageBox msgBox;
        msgBox.setWindowTitle("Error");
        msgBox.setText("Not binded port detected.");
        msgBox.addButton("ok", QMessageBox::YesRole);
        msgBox.exec();
    }
    else if (scheme.containCycle()) {
        QMessageBox msgBox;
        msgBox.setWindowTitle("Error");
        msgBox.setText("Cycle detected.");
        msgBox.addButton("ok", QMessageBox::YesRole);
        msgBox.exec();
    }
    else {
        for (int i = 0; i < allBlocks.size(); i++) {
            if (!allBlocks.at(i)->bblock->myVal.defined) {
                scheme.nextStep();
            }
        }
        updateBlockValues();
    }
}

void DiagramScene::debugBtnClicked()
{
    if (scheme.containNotBindedPort()) {
        QMessageBox msgBox;
        msgBox.setWindowTitle("Error");
        msgBox.setText("Not binded port detected.");
        msgBox.addButton("ok", QMessageBox::YesRole);
        msgBox.exec();
    }
    else if (scheme.containCycle()) {
        QMessageBox msgBox;
        msgBox.setWindowTitle("Error");
        msgBox.setText("Cycle detected.");
        msgBox.addButton("ok", QMessageBox::YesRole);
        msgBox.exec();
    }
    else {
        for (int i = 0; i < allBlocks.size(); i++) {
            if (allBlocks.at(i)->bblock->blockType == BLOCK_INPUT) {
                if (!allBlocks.at(i)->bblock->myVal.defined)
                   scheme.nextStep();
            }
        }
        scheme.nextStep();
        updateBlockValues();
    }
}

void DiagramScene::updateBlockValues()
{
    for (int i = 0; i < allBlocks.count(); i++) {
        Block *b = allBlocks.at(i);
        if (b->bblock->myVal.defined) {
            b->displayValue(b->bblock->myVal.value);
        }
    }

    update();
}

void DiagramScene::save()
{
    QString filename = QFileDialog::getSaveFileName();

    if (filename.isEmpty())
            return;

    QFile f(filename);
    f.open(QFile::WriteOnly);
    QDataStream oStream(&f);

    int blocksNum = allBlocks.length();
    oStream << blocksNum;

    for (Block *b : allBlocks) {
        oStream << (quint64) b;
    }

    for (Block *b : allBlocks) {
        oStream << BLOCKT;
        oStream << b->thisType;
        b->save(oStream);
    }

    for (Wire *w: allWires) {
        oStream << WIRET;
        w->save(oStream);
    }

}

void DiagramScene::load()
{
    QString filename = QFileDialog::getOpenFileName();

    QFile f(filename);
    f.open(QFile::ReadOnly);
    QDataStream iStream(&f);

    // remove all object at the scene
    this->clear();
    this->allBlocks.clear();
    this->scheme.allBlocks.clear();

    int blocksNum;
    iStream >> blocksNum;

    QMap<int, Block *> indexOldPointerMap;
    for (int i = 0; i < blocksNum; i++) {
        quint64 intP;
        iStream >> intP;
        indexOldPointerMap.insert(i, (Block *) intP);
    }

    QMap<Block *, Block *> oldNewPointerMap;

    int i = 0;
    while (!iStream.atEnd())
    {
        int objType;
        iStream >> objType;
        if ((SceneObjectType)objType == BLOCKT) {
            int bType;
            iStream >> bType;
            Block *block = CreateBlockByType((BlockType)bType);
            addBlockToList(block);
            addItem(block);
            block->load(iStream);
            oldNewPointerMap.insert(indexOldPointerMap[i], block);
            i++;
        } else {
            // WIRE
            Wire *wire = new Wire(this);
            wire->load(iStream, oldNewPointerMap);
            addItem(wire);
        }
    }
    update();
}

Block *DiagramScene::CreateBlockByType(BlockType bType)
{
    if (bType == BLOCK_ADD || bType == BLOCK_SUB || bType == BLOCK_MUL || bType == BLOCK_DIV) {
        return new CalculatingBlock(bType, this);
    }
    else if (bType == BLOCK_RESULT) {
        return new ResultBlock(this);
    }
    else if (bType == BLOCK_INPUT) {

        return new InputBlock(this, 0);
    } else {
        return nullptr;
    }
}
