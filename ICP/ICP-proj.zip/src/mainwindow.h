// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: mainwindow.h

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "includes.h"
#include "diagramscene.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_CalculateBtn_clicked();

    void on_DebugBtn_clicked();

    void on_actionSave_triggered();

    void on_actionLoad_triggered();

private:
    Ui::MainWindow *ui;
    DiagramScene *scene;
};

#endif // MAINWINDOW_H
