// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: calculatingblock.cpp

#include "calculationblock.h"
#include "b_calculationblock.h"

CalculatingBlock::CalculatingBlock(BlockType blockType, DiagramScene *mainScene):
    Block(mainScene),
    inPort1(-45, -20, PORT_IN_0, this),
    inPort2(-45, 10, PORT_IN_1, this),
    outPort(35, -5, PORT_OUT, this)
{
    inPort1.setParentItem(this);
    inPort2.setParentItem(this);
    outPort.setParentItem(this);

    switch (blockType) {
        case BLOCK_ADD:
            icon.setText("+");
            break;
        case BLOCK_SUB:
            icon.setText("-");
            break;
        case BLOCK_MUL:
            icon.setText("×");
            break;
        case BLOCK_DIV:
            icon.setText("÷");
            break;
        default:
            break;
    }
    bblock = new B_CalculationBlock(blockType);
    this->mainScene = mainScene;
    mainScene->scheme.addBlock(bblock);
}


void CalculatingBlock::deleteThis()
{
    inPort1.clearPort();
    inPort2.clearPort();
    outPort.clearPort();
    this->scene()->update();
    delete this;
}

Port *CalculatingBlock::getPortPointer(PortType portType)
{
    switch (portType) {
        case PORT_IN_0:
            return &inPort1;
        case PORT_IN_1:
            return &inPort2;
        case PORT_OUT:
            return &outPort;
    }

    return nullptr;
}
