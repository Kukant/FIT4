// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: b_resultblock.cpp

#include "b_resultblock.h"

B_ResultBlock::B_ResultBlock() : B_Block(1)
{
    this->blockType = BLOCK_RESULT;
}

double B_ResultBlock::calculate() {
    return this->inputValues.at(0).value;
}
