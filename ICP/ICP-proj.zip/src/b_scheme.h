// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: b_scheme.h

#ifndef B_SCHEME_H
#define B_SCHEME_H

#include "includes.h"
#include "b_block.h"

class B_Scheme
{
public:
    B_Scheme();
    void addBlock(B_Block *b);
    void removeBlock(B_Block *b);
    void nextStep();
    void calculateAll();
    std::vector<B_Block *> allBlocks;

    /**
     * Checks if scheme contains some unbinded ports.
     * @return True if does, false otherwise.
     */
    bool containNotBindedPort();

    /**
     * Checks if scheme contains a cycle.
     * @return True if does, false otherwise.
     */
    bool containCycle();

private:
    /**
     * Auxiliary method for containCycle().
     * @return True if cycle was detected, false otherwise.
     */
    bool containCycleUtil(B_Block *block, std::vector<B_Block *> &inPath);
};

#endif // B_SCHEME_H
