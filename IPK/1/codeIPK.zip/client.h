/**
 * Created by Tomas Kukan, xkukan00, 11. 3. 2018
 */

#ifndef INC_1_CLIENT_H
#define INC_1_CLIENT_H

int getParams(int argc, char *argv[]);

#endif //INC_1_CLIENT_H
