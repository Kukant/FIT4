// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: port.cpp

#include "port.h"
#include "wire.h"

Port::Port(double x, double y, PortType type, Block *parentBlock)
{
    portType = type;
    setFlag(QGraphicsItem::ItemIsMovable, false);
    setFlag(QGraphicsItem::ItemIsSelectable, false);
    setFlag(QGraphicsItem::ItemSendsGeometryChanges, false);

    QRectF rect(x, y, 10, 10);
    used = false;
    rectangle = rect;

    connectedWires = new QList<Wire *>();
    this->parentBlock = parentBlock;
}

void Port::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->setBrush(Qt::black);
    painter->drawRect(rectangle);
    (void) option; // only for dissapear of warning
    (void) widget; // only for dissapear of warning
}

ObjectType Port::getObjType()
{
    return OBJ_PORT;
}

QPointF Port::centerPoint()
{
    return mapToScene(this->rectangle.center());
}

QRectF Port::boundingRect() const
{
    return rectangle;
}

void Port::clearPort()
{
    QList<Wire *> *tmpList = new QList<Wire *>();
     for (int i = 0; i < connectedWires->length(); i++)  {
         tmpList->append(connectedWires->at(i));
     }

    for (int i = 0; i < tmpList->length(); i++) {
        tmpList->at(i)->removeWire();
    }
    delete tmpList;
}

int Port::connectWire(Wire *toConnect)
{
    if ((portType == PORT_IN_0 || portType == PORT_IN_1)  && connectedWires->length() != 0) {
        return 1;
    } else {
        connectedWires->append(toConnect);
        return 0;
    }
}

void Port::disconnectWire(Wire *toDisconnect)
{
    int indexToDel = -1;

    for (int i = 0; i < connectedWires->length(); i++)
        if (connectedWires->at(i) == toDisconnect)
            indexToDel = i;

    if (indexToDel == -1) {
    	; // ToDo
    } else {
        connectedWires->removeAt(indexToDel);
    }
}
