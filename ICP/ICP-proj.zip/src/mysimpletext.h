// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: mysipletext.h

#ifndef MYSIMPLETEXT_H
#define MYSIMPLETEXT_H

#include "includes.h"

/**
 * @class MySimpleText
 * @defgroup Text
 * @ingroup Text
 *
 * This class set text.
 */
class MySimpleText : public QGraphicsSimpleTextItem
{
public:
    /**
     * Create an MySimpleText.
     * @param text ToDo
     * @param parent ToDo
     */
    MySimpleText(const QString &text, QGraphicsItem *parent = nullptr);

    /**
     * Only because of inheritance from DiagramSceneObject (virtual method).
     */
    QRectF boundingRect() const;

    /**
     * Only because of inheritance from DiagramSceneObject (virtual method).
     */
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};

#endif // MYSIMPLETEXT_H
