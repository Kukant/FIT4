// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: resultblock.h

#ifndef RESULTBLOCK_H
#define RESULTBLOCK_H

#include "includes.h"
#include "block.h"
#include "port.h"

/**
 * @class ResultBlock
 * @ingroup Frontend block
 *
 * This class represents block for display result of scheme.
 */
class ResultBlock : public Block
{
public:
    /**
     * Create an ResultBlock.
     * @param mainScene Parameter for block (parent) constructor.
     */
    ResultBlock(DiagramScene *mainScene);

private:
    /**
     * Input port.
     */
    Port inPort;

    /**
     * ToDo.
     */
    virtual void deleteThis() Q_DECL_OVERRIDE;

    /**
     * ToDo.
     */
    virtual Port *getPortPointer(PortType portType) Q_DECL_OVERRIDE;
};

#endif // RESULTBLOCK_H
