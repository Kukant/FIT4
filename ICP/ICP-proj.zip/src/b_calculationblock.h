// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: b_calculationblock.h

#ifndef B_CALCULATIONBLOCK_H
#define B_CALCULATIONBLOCK_H

#include "includes.h"
#include "b_block.h"
#include "diagramscene.h"
#include "b_calculationblock.h"

/**
 * @class B_CalculationBlock
 * @defgroup Backend calculation block
 * @ingroup Backend calculation block
 *
 * This is specific block that does calculations.
 */
class B_CalculationBlock : public B_Block
{
public:
    B_CalculationBlock(BlockType blockType);
private:
    double calculate();
};

#endif // B_CALCULATIONBLOCK_H
