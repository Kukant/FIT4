// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: mainwindow.cpp

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <string>
#include <iostream>
#include <QImage>
#include <QPixmap>
#include <QString>
#include <QListWidgetItem>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // create and set scene
    scene = new DiagramScene(this);
    scene->listWidget = ui->listWidget;
    ui->graphicsView->setScene(scene);
    ui->listWidget->setContentsMargins(0, 0, 0, 0);

    // fill list with images
    std::array<QString, 6>  imagepaths = { "add.png", "sub.png", "mul.png", "div.png", "result.png", "input.jpg"};

    // display images
    for (QString path : imagepaths) {
        QString wholePath = ":/images/" + path;
        QPixmap img(wholePath);
        img = img.scaledToWidth(68);
        QListWidgetItem *item = new QListWidgetItem("", ui->listWidget);
        item->setTextAlignment(Qt::AlignCenter);
        item->setSizeHint(QSize(70, 70));
        item->setData(Qt::DecorationRole, img);
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_CalculateBtn_clicked()
{
    scene->calculateBtnClicked();
}

void MainWindow::on_DebugBtn_clicked()
{
    scene->debugBtnClicked();
}

void MainWindow::on_actionSave_triggered()
{
    scene->save();
}

void MainWindow::on_actionLoad_triggered()
{
    scene->load();
}
