// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: b_calculatingblock.cpp

#include "b_calculationblock.h"
#include "b_block.h"
#include <QMessageBox>
B_CalculationBlock::B_CalculationBlock(BlockType blockType):
    B_Block(2)
{
    this->blockType = blockType;
}

double B_CalculationBlock::calculate() {
    double leftOperand,rightOperand;
    leftOperand = this->inputValues.at(0).value;
    rightOperand = this->inputValues.at(1).value;
    switch (blockType) {
    case BLOCK_ADD:
        return leftOperand + rightOperand;
        break;
    case BLOCK_SUB:
        return leftOperand - rightOperand;
        break;
    case BLOCK_MUL:
        return leftOperand * rightOperand;
        break;
    case BLOCK_DIV:
        if (rightOperand == 0) {
            QMessageBox msgBox;
            msgBox.setWindowTitle("Error");
            msgBox.setText("Zero division! Value set to zero.");
            msgBox.addButton("ok", QMessageBox::YesRole);
            msgBox.exec();
            return 0;
        }
        return leftOperand / rightOperand;
        break;
    default:
        break;
    }

    return 666;
}
