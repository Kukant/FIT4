// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: inputblock.cpp

#include "inputblock.h"
#include "b_inputblock.h"
#include "diagramscene.h"

InputBlock::InputBlock(DiagramScene *mainScene, double value):
    Block(mainScene),
    outPort(35, -5, PORT_OUT, this)
{
    outPort.setParentItem(this);
    icon.setText("N");

    this->value = value;
    displayValue(value);

    bblock = new B_InputBlock(value);
    this->mainScene = mainScene;
    mainScene->scheme.addBlock(bblock);

    thisType = BLOCK_INPUT;
}

void InputBlock::deleteThis()
{
    outPort.clearPort();
    mainScene->update();
    delete this;
}

void InputBlock::save(QDataStream &stream)
{
    stream << pos();
    stream << value;
}

void InputBlock::load(QDataStream &stream)
{
    QPointF pos;
    stream >> pos;
    this->setPos(pos);
    stream >> value;
    displayValue(value);
    bblock->myVal.value = value;
}

Port *InputBlock::getPortPointer(PortType portType)
{
    switch (portType) {
        case PORT_IN_0:
            return nullptr;
        case PORT_IN_1:
            return nullptr;
        case PORT_OUT:
            return &outPort;
    }
    return nullptr;
}
