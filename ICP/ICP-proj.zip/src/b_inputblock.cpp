// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: b_inputblock.cpp

#include "b_inputblock.h"
#include "b_block.h"

B_InputBlock::B_InputBlock(double in): B_Block(0)
{
    myVal.value = in;
    myVal.defined = false;
    this->blockType = BLOCK_INPUT;
}

double B_InputBlock::calculate() {
    return myVal.value;
}
