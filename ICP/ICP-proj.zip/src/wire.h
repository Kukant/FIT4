// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: wire.h

#ifndef WIRE_H
#define WIRE_H

#include "includes.h"
#include "diagramsceneobject.h"
#include "port.h"
#include "diagramscene.h"

/**
 * @class Wire
 * @defgroup Frontend wire
 * @ingroup Frontend wire
 *
 * This class represents wire among blocks.
 */
class Wire : public DiagramSceneObject
{
public:
    /**
     * Create a Wire.
     * @param origin ToDo
     * @param end ToDo
     * @param mainScene ToDo
     */
    Wire(Port *origin, Port *end, DiagramScene *mainScene);

    /**
     * ToDo.
     */
    Wire(DiagramScene *mainScene);

    /**
     * ToDo.
     */
    void removeWire();

    /**
     * ToDo.
     */
    void save(QDataStream &stream);

    /**
     * ToDo.
     */
    void load(QDataStream &stream, QMap<Block *, Block *> &oldNewPointerMap);

private:
    /**
     * ToDo.
     */
    DiagramScene *mainScene;

    /**
     * Only because of inheritance from DiagramSceneObject (virtual method).
     */
    QRectF boundingRect()const Q_DECL_OVERRIDE;

    /**
     * Only because of inheritance from DiagramSceneObject (virtual method).
     */
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) Q_DECL_OVERRIDE;

    /**
     * Origin port.
     */
    Port *originPort;

    /**
     * Ending port.
     */
    Port *endingPort;

    /**
     * Pen (color, width).
     */
    QPen *pen;

    /**
     * ToDo.
     */
    QPointF startingPoint;

    /**
     * ToDo.
     */
    QPointF endingPoint;
};

#endif // WIRE_H
