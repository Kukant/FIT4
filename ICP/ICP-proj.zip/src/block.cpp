// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: block.cpp

#include "block.h"
#include "diagramscene.h"

Block::Block(DiagramScene *mainScene):
    icon(""),
    text(""),
    rect(-35, -35, 70, 70)
{
    this->mainScene = mainScene;
    setFlag(QGraphicsItem::ItemIsMovable, true);
    setFlag(QGraphicsItem::ItemIsSelectable, true);
    setFlag(QGraphicsItem::ItemSendsGeometryChanges, true);

    QFont font("Monospace");
    font.setPixelSize(36);
    font.setWeight(500);

    icon.setFont(font);
    icon.setParentItem(this);
    icon.setPos(-11, -30);

    font.setPixelSize(14);
    text.setFont(font);
    text.setParentItem(this);
    text.setPos(-30, 15);

    setZValue(BLOCK_Z_VALUE);
}

void Block::displayValue(double value)
{
    std::string str = std::to_string(value);
    str.erase(str.find_last_not_of('0') + 1, std::string::npos);

    if (str.back() == '.')
        str = str.substr(0, str.size() - 1);

    if (str.length() > 7) {
        if (value >= 100000)
            text.setText(QString("%1").arg(value, 0, 'g', 3));
        else if (value >= 10000)
            text.setText(QString("%1").arg(value, 0, 'f', 1));
        else if (value >= 1000)
            text.setText(QString("%1").arg(value, 0, 'f', 2));
        else if (value >= 100)
            text.setText(QString("%1").arg(value, 0, 'f', 3));
        else if (value >= 10)
            text.setText(QString("%1").arg(value, 0, 'f', 4));
        else if (value >= 1)
            text.setText(QString("%1").arg(value, 0, 'f', 5));
        else
            text.setText(QString("%1").arg(value, 0, 'f', 5));
    }
    else {
        text.setText(QString::fromStdString(str));
    }
}

ObjectType Block::getObjType()
{
    return OBJ_BLOCK;
}

void Block::setText(double val)
{
    text.setText(QString::number(val));
}

void Block::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if (event->button() == Qt::RightButton)
    {
        mainScene->scheme.removeBlock(bblock);
        mainScene->removeBlockFromList(this);
        deleteThis();
    }

    QGraphicsObject::mousePressEvent(event);
}

void Block::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->setBrush(Qt::white);
    painter->drawRect(rect);
    (void) option; // only for dissapear of warning
    (void) widget; // only for dissapear of warning
}

QRectF Block::boundingRect() const
{
    return rect;
}

void Block::deleteThis()
{
    delete this;
}

Port *Block::getPortPointer(PortType portType)
{
    (void) portType; // only for dissapear of warning
    return nullptr;
}

void Block::save(QDataStream &stream) {
    stream << pos();
}

void Block::load(QDataStream &stream) {
    QPointF pos;
    stream >> pos;
    this->setPos(pos);
}
