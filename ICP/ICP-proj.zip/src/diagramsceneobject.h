// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: diagramsceneobject.h

#ifndef DIAGRAMSCENEOBJECT_H
#define DIAGRAMSCENEOBJECT_H

#include "includes.h"
#include "enums.h"

class DiagramSceneObject : public QGraphicsObject
{
public:
    DiagramSceneObject();
    virtual ObjectType getObjType();
    virtual QPointF centerPoint();
};

#endif // DIAGRAMSCENEOBJECT_H
