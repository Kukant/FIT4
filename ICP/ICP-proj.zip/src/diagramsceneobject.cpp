// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: diagramsceneobject.cpp

#include "diagramsceneobject.h"

DiagramSceneObject::DiagramSceneObject()
{
}

ObjectType DiagramSceneObject::getObjType()
{
    return OBJ_NONE;
}

QPointF DiagramSceneObject::centerPoint()
{
    return QPointF(0, 0);
}

