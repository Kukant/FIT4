// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: b_block.h

#ifndef B_BLOCK_H
#define B_BLOCK_H

#include "includes.h"
#include "enums.h"

class B_Block;

struct Value {
    bool defined;
    double value;
};

struct Block_IndexT {
    B_Block *block;
    int index;
};

/**
 * @class B_Block
 * @defgroup Backend block
 * @ingroup Backend block
 *
 * This class represents general block, specific types of blocks inherit from it.
 */
class B_Block
{
public:
    B_Block(int inputsNum = 0);

    struct Value myVal;
    std::vector<Value> inputValues;

    void bindOutput(B_Block *b, int index);
    void bindInput(B_Block *b, int index);
    void unbindInputs();
    void unbindOutput(B_Block *b, int index);
    int sendVal();
    BlockType blockType;

    std::vector<B_Block *> inputs;
    QList<Block_IndexT *> outputs;

private:
    void unbindInput(int index);

    virtual double calculate() {return 0;}
};

#endif // B_BLOCK_H
