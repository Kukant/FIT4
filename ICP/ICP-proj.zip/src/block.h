// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: block.h

#ifndef BLOCK_H
#define BLOCK_H

#include "includes.h"
#include "mysimpletext.h"
#include "port.h"
#include "diagramsceneobject.h"
#include "mysimpletext.h"
#include "enums.h"

class B_Block;
class DiagramScene;

/**
 * @class Block
 * @defgroup Frontend block
 * @ingroup Frontend block
 *
 * This class represents general block, specific types of blocks inherit from it.
 */
class Block : public DiagramSceneObject
{
public:
    /**
     * Create an Block.
     * @param mainScene Set as mainScene attribute.
     */
    Block(DiagramScene *mainScene);

    /**
     * Pointer to the backend block.
     */
    B_Block *bblock;

    /**
     * Type of the block.
     */
    BlockType thisType;

    /**
     * Get type of an object.
     * @return Type of object (block in this case).
     */
    ObjectType getObjType();

    /**
     * Display value of a block in a scene.
     * @param value The value to be displayed.
     */
    void displayValue(double value);

    /**
     * ToDo
     */
    virtual void save(QDataStream &stream);

    /**
     * ToDo
     */
    virtual void load(QDataStream &stream);

    /**
     * Get pointer of the port.
     *
     * @param portType What port should be return.
     * @return Pointer to the port set as parameter.
     */
    virtual Port *getPortPointer(PortType portType);

protected:
    /**
     * Pointer to the main scene.
     */
    DiagramScene *mainScene;

    /**
     * Icon (block type) of the block.
     */
    MySimpleText icon;

    /**
     * Set text attribute.
     *
     * @param val Value on what should be attribute text set.
     */
    void setText(double val);

private:
    /**
     * Text (value) of the block.
     */
    MySimpleText text;

    /**
     * Form of the block (rectangle).
     */
    QRectF rect;

    /**
     * Defines what happen when mouse button is pressed.
     *
     * @param event Event.
     */
    void mousePressEvent(QGraphicsSceneMouseEvent *event);

    /**
     * Only because of inheritance from DiagramSceneObject (virtual method).
     */
    QRectF boundingRect() const Q_DECL_OVERRIDE;

    /**
     * Only because of inheritance from DiagramSceneObject (virtual method).
     */
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) Q_DECL_OVERRIDE;

    /**
     * ToDo
     */
    virtual void deleteThis();
};

#endif // BLOCK_H
