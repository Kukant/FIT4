// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: diagramscene.h

#ifndef DIAGRAMSCENE_H
#define DIAGRAMSCENE_H

#include "includes.h"
#include "port.h"
#include "block.h"
#include "diagramsceneobject.h"
#include "b_scheme.h"

class DiagramScene : public QGraphicsScene
{
public:
    enum Mode {movingObject, creatingLine};
    DiagramScene(QObject *parent = 0);
    QListWidget *listWidget;
    DiagramSceneObject *getObjectUnderCursor(QPointF position);
    void addBlockToList(Block *b);
    void removeBlockFromList(Block *b);
    void calculateBtnClicked();
    void debugBtnClicked();
    void save();
    void load();
    B_Scheme scheme;
    QList<Block *> allBlocks;
    QList<Wire *> allWires;

private:
    Block *CreateBlockByType(BlockType bType);
    void updateBlockValues();
    void mousePressEvent(QGraphicsSceneMouseEvent *event) Q_DECL_OVERRIDE;
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) Q_DECL_OVERRIDE;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) Q_DECL_OVERRIDE;
    Mode currentMode = movingObject;
    QGraphicsLineItem *newLine = NULL;
    Port *startingPort;

};

#endif // DIAGRAMSCENE_H
