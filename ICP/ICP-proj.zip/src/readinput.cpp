// VUT FIT
// ICP 2017/2018
// Project: BlockEditor
// Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)
// Date: 6/5/2018
// File: readinput.cpp

#include "readinput.h"
#include "ui_readinput.h"

ReadInput::ReadInput(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ReadInput)
{
    ui->setupUi(this);
    ui->lineEdit->setValidator(new QDoubleValidator(-10000, 10000, 10, this));
}

ReadInput::~ReadInput()
{
    delete ui;
}

double ReadInput::getInputValue()
{
    return ui->lineEdit->text().toDouble();
}
