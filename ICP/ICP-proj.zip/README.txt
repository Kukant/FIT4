# ICP-proj  

**Základní informace**  

VUT FIT  
ICP 2017/2018  
Project: Application BlockEditor  
Authors: Vladimir Dusek (xdusek27), Tomas Kukan (xkukan00)  
Date: 4/5/2018  

**Struktura repozitáře**  

src/ ... Zdrojové soubory  
examples/ ... Příklady pro testování  
doc/ ... Doxygen dokumentace  
README.MD  
Makefile  

**Použití**  

	$ make 
	$ make clean
	$ make run
	$ make doxygen
	$ make pack

